<!DOCTYPE html>
<html>
<?php get_header(); ?>
<body>
		<ul>
			<?php wp_list_pages("title_li="); ?>
		</ul>
	<div id="box-text">
		<h2 class="staff" style="margin-bottom: 10px">> [DeepMice] <span style="color: #f0a78e;">Welcome to Game</span></h2>
		<h2 class="adm">[•] [Administrator] <span style="color: #92cf91;">We hope you have great experiences on our server,
Any questions or suggestions contact a team member. or access our <a href='/' alt='#' title='#' style="color: #c2c2da; text-decoration: underline;">Page of
Contact.</a><span></h2>
	</div>
	<!-- OUTER  -->
	<div id="outer-wrapper">
		<div id="f">
		<div id="jogo">
<script type="text/javascript" src="http://transformice.com/youtube-tfm.js"></script>
<script type="text/javascript" src="http://transformice.com/lib.js"></script>
	<div id="transformice" style="width:100%;height:100%;">
		<object id="swf1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="100%" height="100%" id="Transformice" align="middle">
		<param name="allowScriptAccess" value="always" />
		<param name="movie" value="http://deepmice.top/158.swf" />
		<param name="menu" value="true" />
		<param name="quality" value="high" />
		<param name="bgcolor" value="#6A7495" />
		<embed id="swf2" src="http://deepmice.top/158.swf" wmode="direct" menu="true" quality="high" bgcolor="#6A7495" width="100%" height="100%" name="Transformice" align="middle" swLiveConnect="true" allowFullScreen="true" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
		</object>
	</div>
		</div>
		<div id="ads">
		</div>
	</div>

 <?php
	if(have_posts()) : while(have_posts()) : the_post();
?>
		<div id="post" id="post-<?php the_ID(); ?>">
			<div id="post-title">
			<a href="<?php the_permalink(); ?>" title=""><?php the_title(); ?></a></div>
			<div id="post-body">
				<div id="post-info">
					<div id="avatar"><?php echo get_avatar(get_the_author_meta('ID'), 100); ?></div>
					<span class="autor"><?php the_author();?></span>
					<span class="data"><?php the_time('d/m/Y') ?></span>
				</div>
				<div class="post-body">
					<?php the_content(); ?>
				</div>
			</div>
		</div>
<?php 
	endwhile;
	else:
?>
<?php
	endif;
?>
	</div>
	<footer>
		&#169; Copyrights <?php the_time('Y') ?> <?php bloginfo("name"); ?>. All Rights Reserved | Powered by <a href="http://wordpress.org/">WordPress</a> theme by Adrian</div>
	</footer>
</body>
</html>