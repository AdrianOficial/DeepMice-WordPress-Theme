<?php get_header(); ?>
</div>

<?php
	if(have_posts()) : while(have_posts()) : the_post();
?>
	<div id="box-text">
		<h2 class="staff" style="margin-bottom: 10px">
		<center><span style="color: #f0a78e;"><?php the_title(); ?></span></center>
		<br>
		<br>
		<span style="color: #92cf91;"><?php the_content(); ?></span>
		</h2>
	</div>
<?php 
	endwhile;
	else:
?>
<?php
	endif;
?>